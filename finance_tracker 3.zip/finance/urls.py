from django.urls import path
from . import views
from .views import home

urlpatterns = [
    path('', home, name='home'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('income_form/', views.log_income, name='log_income'),
    path('expense_form/', views.log_expense, name='log_expense'),
]