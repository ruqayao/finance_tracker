from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required

from .forms import SignupForm, IncomeForm, ExpenseForm

def home(request):
    return render(request, 'finance/home.html')
def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('log_income')
    else:
        form = SignupForm()
    return render(request, 'finance/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('log_income')
    else:
        form = AuthenticationForm()
    return render(request, 'finance/login.html', {'form': form})

@login_required
def log_income(request):
    if request.method == 'POST':
        form = IncomeForm(request.POST)
        if form.is_valid():
            income = form.save(commit=False)
            income.user = request.user
            income.save()
            return redirect('log_income')
    else:
        form = IncomeForm()
    return render(request, 'finance/income_form.html', {'form': form})

@login_required
def log_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            return redirect('log_expense')
    else:
        form = ExpenseForm()
    return render(request, 'finance/expense_form.html', {'form': form})