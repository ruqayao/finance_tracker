from django.urls import path
from . import views
from .views import home

from .views import logout_view

urlpatterns = [
    path('', home, name='home'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('income_form/', views.log_income, name='log_income'),
    path('expense_form/', views.log_expense, name='log_expense'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', logout_view, name='logout'),
    path('api/expenses/', views.api_expenses, name='api_expenses'),
    path('api/spending-trends/', views.api_spending_trends, name='api_spending_trends'),
    path('api/savings-prediction/', views.api_savings_prediction, name='api_savings_prediction'),
]