from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required

from .forms import SignupForm, IncomeForm, ExpenseForm

from django.contrib.auth import logout
from django.shortcuts import redirect

def logout_view(request):
    logout(request)
    return redirect('home')
def home(request):
    return render(request, 'finance/home.html')
def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('log_income')
    else:
        form = SignupForm()
    return render(request, 'finance/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('log_income')
    else:
        form = AuthenticationForm()
    return render(request, 'finance/login.html', {'form': form})

@login_required
def log_income(request):
    if request.method == 'POST':
        form = IncomeForm(request.POST)
        if form.is_valid():
            income = form.save(commit=False)
            income.user = request.user
            income.save()
            return redirect('log_income')
    else:
        form = IncomeForm()
    return render(request, 'finance/income_form.html', {'form': form})

@login_required
def log_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            return redirect('log_expense')
    else:
        form = ExpenseForm()
    return render(request, 'finance/expense_form.html', {'form': form})

import requests
import json
from django.core.serializers.json import DjangoJSONEncoder
from .models import Income, Expense

from decimal import Decimal
@login_required
def dashboard(request):
    incomes = Income.objects.filter(user=request.user)
    expenses = Expense.objects.filter(user=request.user)

    total_income = sum(i.amount for i in incomes)
    total_expense = sum(e.amount for e in expenses)

    try:
        response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
        data = response.json()
        exchange_rate = data['rates'].get('EUR', 1)
    except Exception:
        exchange_rate = 1

    income_labels = [i.category.name if i.category else "Uncategorized" for i in incomes]
    income_data = [i.amount for i in incomes]
    expense_labels = [e.category.name if e.category else "Uncategorized" for e in expenses]
    expense_data = [e.amount for e in expenses]

    context = {
        'total_income': total_income,
        'total_expense': total_expense,
        'exchange_rate': exchange_rate,
        'total_income_eur': total_income * Decimal(str(exchange_rate)),
        'income_labels': json.dumps(income_labels, cls=DjangoJSONEncoder),
        'income_data': json.dumps(income_data, cls=DjangoJSONEncoder),
        'expense_labels': json.dumps(expense_labels, cls=DjangoJSONEncoder),
        'expense_data': json.dumps(expense_data, cls=DjangoJSONEncoder),
    }
    return render(request, 'finance/dashboard.html', context)

from django.http import JsonResponse
from django.db.models import Sum, Avg
from django.db.models.functions import TruncMonth

@login_required
def api_expenses(request):
    expenses = Expense.objects.filter(user=request.user).values('amount', 'category__name', 'date')
    return JsonResponse(list(expenses), safe=False)
@login_required
def api_spending_trends(request):
    trends = Expense.objects.filter(user=request.user) \
        .values('category__name') \
        .annotate(total=Sum('amount')) \
        .order_by('-total')
    return JsonResponse(list(trends), safe=False)
@login_required
def api_savings_prediction(request):
    monthly_totals = Expense.objects.filter(user=request.user) \
        .annotate(month=TruncMonth('date')) \
        .values('month') \
        .annotate(total=Sum('amount')) \
        .order_by('month')

    avg = monthly_totals.aggregate(avg=Avg('total'))['avg'] or 0

    return JsonResponse({'predicted_next_month_expense': avg})